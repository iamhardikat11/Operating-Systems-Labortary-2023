To Run Code between the Preprocessor Directives write those as -D 
E.g:- g++ myfile.cpp -D Test