#ifndef USERPROG_SYSCALL_H
#define USERPROG_SYSCALL_H

#include <stdbool.h>
#include "threads/thread.h"
#include <list.h>
#include "threads/synch.h"


void syscall_init (void);
void exit (int status);
tid_t exec (const char *cmd_line);
int write (int fd, const void *buffer, unsigned size);

struct child_process* get_child(tid_t tid,struct list *mylist);


#endif /* userprog/syscall.h */
