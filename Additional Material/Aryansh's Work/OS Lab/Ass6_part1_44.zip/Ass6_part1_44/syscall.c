#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/vaddr.h"
#include "threads/malloc.h"
#include "devices/shutdown.h"
#include "devices/input.h"
#include "process.h"
#include "filesys/file.h"
#include "filesys/filesys.h"
#include "threads/synch.h"
#include "userprog/pagedir.h"


struct child_process* get_child(int tid,struct list *mylist);
static void syscall_handler (struct intr_frame *);
int syswrite (int fd, const void *buffer_, int size);
int exec_proc (const char *cmdline);
void exit_proc (int status);



bool check_vaddr(void *vaddr){
    if(!is_user_vaddr(vaddr)){
        exit_proc(-1);
        return false;
    }
    void *p=pagedir_get_page(thread_current()->pagedir,vaddr);
    if(!p){
    exit_proc(-1);
    return false;
  }
    return true;
}


void
syscall_init (void)
{
    intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}


static void
syscall_handler (struct intr_frame *f )
{
        int *t=(int*)f->esp;
        check_vaddr(t);
        int syscall_num=*t;

    switch(syscall_num)
    {
    case SYS_EXIT:                   /* Terminate this process. */
        check_vaddr(t+1);
        exit_proc(*(t+1));
        break;
    case SYS_EXEC:                   /* Start another process. */
        check_vaddr(t+1);
        check_vaddr((char*)(*(t+1)));
        int x=exec_proc((const char*)*(t+1));
        f->eax=x;
        break;
    case SYS_WRITE:                   //Write to a file. 
        check_vaddr(t+1);
      check_vaddr(t+2);
      check_vaddr(t+3);
      check_vaddr((char*)(*(t+2)));
      int y=syswrite(*(t+1),(void*)*(t+2),*(t+3));
      f->eax=y;
        break;

    default:
        exit_proc(-1);
        break;
    }
}

void exit_proc(int status){
  if(status<0){
    status=-1;
  }
  struct thread *cur=thread_current();
  thread_current()->status=status;
  struct child_process *tmp=get_child(cur->tid,&cur->parent->child_list);

  if(cur->parent && tmp){
    tmp->curr_stat=status;
  }
  thread_exit();
}


int exec_proc(const char *cmd_line){
  int pid=process_execute(cmd_line);
  struct child_process *cptr=NULL;
  struct thread *cur=thread_current();
  struct list_elem *e;

  for(e=list_begin(&cur->child_list);e!=list_end(&cur->child_list);e=list_next(e)){
    struct child_process *cp=list_entry(e,struct child_process,child_elem);
    if(pid==cp->c_pid){
      cptr=cp;break;
    }
  }
  if(!cptr){
    return -1;
  }
  if(cptr->loaded==false){
    struct thread *child_thread=find_thread(pid);
    sema_down(&child_thread->sema_exec);
  }
  if(cptr->loaded==false){
    list_remove(&cptr->child_elem);
    free(cptr);
    return -1;
  }

  return pid;
}

int syswrite(int fd,const void *buffer,int size){
  //write to console
  if(fd==1){
    putbuf(buffer,size);
    return size;
  }
  return 0;
}


struct child_process*
get_child(int tid, struct list *mylist)
{
    struct list_elem* e;
    for (e = list_begin (mylist); e != list_end (mylist); e = list_next (e))
    {
        struct child_process *child = list_entry (e, struct child_process, child_elem);
        if(child -> c_pid == tid)
        {
            return child;
        }
    }
    return NULL;
}

