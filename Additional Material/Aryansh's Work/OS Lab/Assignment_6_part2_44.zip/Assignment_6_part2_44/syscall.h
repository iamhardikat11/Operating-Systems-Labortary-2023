#ifndef USERPROG_SYSCALL_H
#define USERPROG_SYSCALL_H

#include <stdbool.h>
#include "threads/thread.h"
#include <list.h>
#include "threads/synch.h"


void syscall_init (void);
void exit_proc (int status);
tid_t exec_proc (const char *cmd_line);
int syswrite (int fd, const void *buffer, int size);
bool syscreate(const char *file,unsigned initial_size);
bool sysremove(const char *file);
int sysopen(const char *file);
int filesize(int fd);
int sysread(int fd,void *buffer,unsigned size);
void sysclose(int fd);
int syswait(tid_t pid);

struct child_process* get_child(tid_t tid,struct list *mylist);

struct fd_struct{              //structure to represent a file decriptor
    int fd;
    struct file *fileptr;
    struct list_elem file_elem;
};

struct lock file_lock;          //prevents concurrent execution of filesystem code


#endif /* userprog/syscall.h */
