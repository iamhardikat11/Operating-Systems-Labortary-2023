#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/vaddr.h"
#include "threads/malloc.h"
#include "devices/shutdown.h"
#include "devices/input.h"
#include "process.h"
#include "filesys/file.h"
#include "filesys/filesys.h"
#include "threads/synch.h"
#include "userprog/pagedir.h"



static void syscall_handler (struct intr_frame *);
int syswrite (int fd, const void *buffer_, int size);
int exec_proc (const char *cmdline);
void exit_proc (int status);
bool syscreate(const char *file,unsigned initial_size);
bool sysremove(const char *file);
int sysopen(const char *file);
int filesize(int fd);
int sysread(int fd,void *buffer,unsigned size);
void sysclose(int fd);
int syswait(tid_t pid);
struct fd_struct *getfd_struct(int fd);
struct child_process* get_child(int tid,struct list *mylist);
bool check_vaddr(void *vaddr);


bool check_vaddr(void *vaddr){
    if(!is_user_vaddr(vaddr)){
        exit_proc(-1);
        return false;
    }
    void *p=pagedir_get_page(thread_current()->pagedir,vaddr);
    if(!p){
      exit_proc(-1);
      return false;
    }
    return true;
}


void
syscall_init (void)
{
    intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
    lock_init(&file_lock);
}


static void
syscall_handler (struct intr_frame *f )
{
    int *t=(int*)f->esp;
    check_vaddr(t);
    int syscall_num=*t;

    switch(syscall_num)
    {
    case SYS_EXIT:                   // Terminate this process. 
        check_vaddr(t+1);
        exit_proc(*(t+1));
        break;
    case SYS_EXEC:                   // Start another process. 
        check_vaddr(t+1);
        check_vaddr((char*)(*(t+1)));
        int x1=exec_proc((const char*)*(t+1));
        f->eax=x1;
        break;
    case SYS_WRITE:                   //Write to a file. 
      check_vaddr(t+5);
      check_vaddr(t+6);
      check_vaddr(t+7);
      check_vaddr((void*)*(t+6));
      int y1=syswrite(*(t+5),(const void*)*(t+6),*(t+7));
      f->eax=y1;
        break;
    case SYS_WAIT:
      check_vaddr(t+1);
      f->eax=syswait(*(t+1));
      break;
    case SYS_CREATE:
      check_vaddr(t+4);
      check_vaddr((void*)*(t+4));
      check_vaddr(t+5);
      bool y2=syscreate((const char*)*(t+4),(unsigned)*(t+5));
      f->eax=y2;
      break;
    case SYS_REMOVE:
      check_vaddr(t+1);
      check_vaddr((void*)*(t+1));
      bool y3=sysremove((const char*)*(t+1));
      f->eax=y3;
      break;
    case SYS_OPEN:
      check_vaddr(t+1);
      check_vaddr((void*)*(t+1));
      int y4=sysopen((const char*)*(t+1));
      f->eax=y4;
      break;
    case SYS_FILESIZE:
      check_vaddr(t+1);
      int y5=filesize(*(t+1));
      f->eax=y5;
      break;
    case SYS_READ:
      check_vaddr(t+5);
      check_vaddr((void*)*(t+6));
      check_vaddr(t+7);
      int y6=sysread(*(t+5),(void *)*(t+6),*(t+7));
      f->eax=y6;
      break;
    case SYS_CLOSE:
      check_vaddr(t+1);
      sysclose(*(t+1));
      break;
    default:
        exit_proc(-1);
        break;
    }
}

void exit_proc(int status){
  if(status<0){
    status=-1;
  }
  struct thread *cur=thread_current();
  struct child_process *tmp=get_child(cur->tid,&cur->parent->child_list);
  tmp->exit_stat=status;

  if(cur->parent && tmp){
    if(status==-1){
      tmp->curr_stat=KILLED;
    }
    else{
      tmp->curr_stat=TERMINATED_ITSELF;
    }
  }
  printf("%s: exit(%d)\n",cur->name,status);
  thread_exit();
}


int exec_proc(const char *cmd_line){
  int pid=process_execute(cmd_line);
  struct child_process *cptr=NULL;
  struct thread *cur=thread_current();
  struct list_elem *e;

  for(e=list_begin(&cur->child_list);e!=list_end(&cur->child_list);e=list_next(e)){
    struct child_process *cp=list_entry(e,struct child_process,child_elem);
    if(pid==cp->c_pid){
      cptr=cp;break;
    }
  }
  if(!cptr){
    return -1;
  }
  if(cptr->loaded==false){
    struct thread *child_thread=find_thread(pid);
    sema_down(&child_thread->sema_exec);
  }
  if(cptr->loaded==false){
    list_remove(&cptr->child_elem);
    free(cptr);
    return -1;
  }

  return pid;
}

int syswrite(int fd,const void *buffer,int size){
  //write to console
  if(fd==1){
    putbuf(buffer,size);
    return size;
  }
  else{
    struct fd_struct *p=getfd_struct(fd);
    int x=-1;
    if(p && buffer){
      lock_acquire(&file_lock);
      struct file *f1=p->fileptr;
      x=file_write(f1,buffer,size);
      lock_release(&file_lock);
    }
    return x;
  }
}

int syswait(tid_t pid){
  return process_wait(pid);
}

bool syscreate(const char *file,unsigned initial_size){
  lock_acquire(&file_lock);
  bool x=filesys_create(file,initial_size);
  lock_release(&file_lock);
  return x;
}

bool sysremove(const char *file){
  lock_acquire(&file_lock);
  bool x=filesys_remove(file);
  lock_release(&file_lock);
  return x;
}

int sysopen(const char *file){
  struct thread *cur=thread_current();
  lock_acquire(&file_lock);
  struct file *opened_file=filesys_open(file);
  lock_release(&file_lock);
  int x;
  if(opened_file!=NULL){
    cur->sizefd++;
    struct fd_struct *p=(struct fd_struct*)malloc(sizeof(struct fd_struct));
    p->fd=cur->sizefd;
    p->fileptr=opened_file;
    list_push_back(&cur->fd_list,&p->file_elem);
    x=p->fd;
  }
  else{x=-1;}
  return x;
}

int filesize(int fd){
  lock_acquire(&file_lock);
  struct fd_struct *tmp=getfd_struct(fd);
  int x=-1;
  if(tmp){
    x=file_length(tmp->fileptr);
  }
  lock_release(&file_lock);
  return x;
}

void sysclose(int fd){
  struct fd_struct *tmp=getfd_struct(fd);
  if(tmp){
    struct file *file1=tmp->fileptr;
    lock_acquire(&file_lock);
    file_close(file1);
    lock_release(&file_lock);
  }
}

int sysread(int fd,void *buffer,unsigned size){
  if(fd==0){
    int x=input_getc();
    return x;
  }
  else{
    int x=-1;
    struct fd_struct *tmp=getfd_struct(fd);
    if(tmp && buffer){
      struct file *file1=tmp->fileptr;
      lock_acquire(&file_lock);
      x=file_read(file1,buffer,size);
      lock_release(&file_lock);
      if(x<(int)size && x){
        x=-1;
      }
    }
    return x;
  }
}

struct fd_struct *getfd_struct(int fd){
  struct thread *cur=thread_current();
  struct list_elem *e;
  for(e=list_begin(&cur->fd_list);e!=list_end(&cur->fd_list);e=list_next(e)){
    struct fd_struct *tmp=list_entry(e,struct fd_struct,file_elem);
    if(tmp->fd==fd){
      return tmp;
    }
  }
  return NULL;
}

struct child_process* get_child(int tid, struct list *mylist)
{
    struct list_elem* e;
    for (e = list_begin (mylist); e != list_end (mylist); e = list_next (e))
    {
        struct child_process *child = list_entry (e, struct child_process, child_elem);
        if(child -> c_pid == tid)
        {
            return child;
        }
    }
    return NULL;
}

